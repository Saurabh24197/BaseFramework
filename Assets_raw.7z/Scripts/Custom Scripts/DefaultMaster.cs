﻿using UnityEngine;
using System.Collections;

namespace BaseFramework
{
	public class DefaultMaster : MonoBehaviour 
	{
        public AudioClip defaultAudioClip;
        public string defaultUIColorHex = "003547D4";



    }
}

