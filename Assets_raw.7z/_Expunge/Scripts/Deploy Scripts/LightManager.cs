﻿using UnityEngine;

public class LightManager : MonoBehaviour
{

    public GameObject lightObj;

    private void OnEnable()
    {
        
    }


}
